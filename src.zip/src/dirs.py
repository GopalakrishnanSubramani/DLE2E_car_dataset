
dirs = {
    "train_data_path" : "/home/krish/Documents/PyTorch/End2End_Deep_learning_project_using_segmentation@classification/car_data/train",
    "test_data_path" : "/home/krish/Documents/PyTorch/End2End_Deep_learning_project_using_segmentation@classification/car_data/val",
    "logging_path" : "/home/krish/Documents/PyTorch/End2End_Deep_learning_project_using_segmentation@classification/",
    "model_dir" :"src/results/models",
    "plot_dir" : "src/results/plots"
}