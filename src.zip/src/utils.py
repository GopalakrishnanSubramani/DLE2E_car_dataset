import torch
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import os
from dataclasses import dataclass
from src.dirs import dirs
matplotlib.style.use('ggplot')

@dataclass
class UtilsConfig:

    model_dir = os.path.join(dirs['model_dir'])
    plot_dir = os.path.join(dirs['plot_dir'])

    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(plot_dir, exist_ok=True)


class Utils:
    def __init__(self):
        self.config = UtilsConfig()


    def save_model(self,name,epochs, model, optimizer, criterion):
        """
        Function to save the trained model to disk.
        """     

        torch.save({
                    'epoch': epochs,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'loss': criterion,
                    }, os.path.join(self.config.model_dir,f"{name}_model.pth"))
        
    def save_plots(self,name,train_acc, valid_acc, train_loss, valid_loss):
        """
        Function to save the loss and accuracy plots to disk.
        """
        # Accuracy plots.
        
        plt.figure(figsize=(10, 7))
        plt.plot(
            train_acc, color='green', linestyle='-', 
            label='train accuracy'
        )
        plt.plot(
            valid_acc, color='blue', linestyle='-', 
            label='validataion accuracy'
        )
        plt.xlabel('Epochs')
        plt.ylabel('Accuracy')
        plt.legend()
        plt.savefig(os.path.join(self.config.plot_dir,f"{name}_accuracy.png"))
        
        # Loss plots.
        plt.figure(figsize=(10, 7))
        plt.plot(
            train_loss, color='orange', linestyle='-', 
            label='train loss'
        )
        plt.plot(
            valid_loss, color='red', linestyle='-', 
            label='validataion loss'
        )
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.legend()
        plt.savefig(os.path.join(UtilsConfig().plot_dir,f"{name}_loss.png"))

    def imshow(self,inp, title=None):
        "Imshow for tensor"
        inp = inp.numpy().transpose((1, 2, 0))
        mean = np.array([0.485, 0.456, 0.406])
        std = np.array([0.229, 0.224, 0.225])
        inp = std * inp + mean
        inp = np.clip(inp, 0, 1)
        plt.figure()
        plt.imshow(inp)
        if title is not None:
            plt.title(title)
        plt.pause(0.001)  # pause a bit so that plots are updated
        plt.show()